﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Test_Assign
{
    public partial class Take_survey : Form
    {
        public Take_survey()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-R930HVOK;Initial Catalog=Test_Assignment;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO Personal_info (Surname,First_Name,Contact_Number,Date,Age) VALUES (@Surname,@First_Name,@Contact_Number,@Date,@Age)", con);

            cmd.Parameters.AddWithValue("@Surname", textBox1.Text);
            cmd.Parameters.AddWithValue("@First_Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Contact_Number", textBox3.Text);
            cmd.Parameters.AddWithValue("@Date", textBox4.Text);
            cmd.Parameters.AddWithValue("@Age", textBox5.Text);
            cmd.ExecuteNonQuery();

            con.Close();

        }
    }
}
